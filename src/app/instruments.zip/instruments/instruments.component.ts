import { Component, EventEmitter, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { InstrumentService } from '../services/instrument.service';

@Component({
  selector: 'app-instruments',
  templateUrl: './instruments.component.html',
  styleUrls: ['./instruments.component.css']
})
export class InstrumentsComponent {
  toppings = new FormControl(); // Initialize FormControl
  toppingList: string[] = ['wan Cheng', 'Bret lee', 'xin ping', 'lee chen'];
  instrumentForm!: FormGroup;
  constructor(private instrumentService:InstrumentService){

  } 

  ngOnInit() {
    this.instrumentForm = new FormGroup({
      instrumentName: new FormControl('', [
        Validators.required, // Field should not be empty
        Validators.minLength(4) // Must have more than 3 characters
      ]),
      // contributorName: new FormControl('', Validators.required), 
      facilityName: new FormControl('', Validators.required),
      facilityFunding: new FormControl('', Validators.required)
    });
  }

  get instrumentName() {
    return this.instrumentForm.get('instrumentName');
  } // Example topping list
 
  onSubmit() {
    if (this.instrumentForm.valid) {
      const instrumentData = {
        instrumentName: this.instrumentForm.value.instrumentName,
        contributors: this.toppings.value,
        facilityName: this.instrumentForm.value.facilityName,
        facilityFunding: this.instrumentForm.value.facilityFunding
      };

      this.instrumentService.addInstrument(instrumentData);
      this.instrumentForm.reset();
      console.log('Submitted instrument:', instrumentData); // Debugging
    }
  }

  
}
